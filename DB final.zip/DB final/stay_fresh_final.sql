-- MySQL dump 10.19  Distrib 10.3.31-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: stay_fresh
-- ------------------------------------------------------
-- Server version	10.3.31-MariaDB-0+deb10u1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `Customer`
--

DROP TABLE IF EXISTS `Customer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Customer` (
  `customerPhone` varchar(20) NOT NULL,
  PRIMARY KEY (`customerPhone`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Customer`
--

LOCK TABLES `Customer` WRITE;
/*!40000 ALTER TABLE `Customer` DISABLE KEYS */;
INSERT INTO `Customer` VALUES ('1318811986'),('1352709817'),('1381719994'),('1442263916'),('1787526756'),('1925114188'),('2028332842'),('2279675601'),('2716649424'),('2823619328'),('2925663685'),('3326195615'),('3504895658'),('3797368836'),('4026788575'),('4094566755'),('4287332730'),('4319002825'),('4412407880'),('4431551615'),('4513996481'),('4928048948'),('5046394625'),('5061693330'),('5067229153'),('5326189365'),('5334619977'),('5352183484'),('5808875364'),('5846462104'),('5951375678'),('5969693637'),('6007695751'),('6395265021'),('7165050817'),('7213390650'),('7621939193'),('7643226405'),('7692294969'),('8065191195'),('8204911992'),('8679067318'),('8969172424'),('8986139597'),('9039125622'),('9049887367'),('9358579997'),('9438651368'),('9966789408');
/*!40000 ALTER TABLE `Customer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CustomerCred`
--

DROP TABLE IF EXISTS `CustomerCred`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `CustomerCred` (
  `customerPhone` varchar(20) NOT NULL,
  `username` varchar(30) NOT NULL,
  `password` text DEFAULT NULL,
  PRIMARY KEY (`customerPhone`),
  UNIQUE KEY `username` (`username`),
  CONSTRAINT `CustomerCred_ibfk_1` FOREIGN KEY (`customerPhone`) REFERENCES `Customer` (`customerPhone`),
  CONSTRAINT `username_not_empty` CHECK (`username` <> '')
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CustomerCred`
--

LOCK TABLES `CustomerCred` WRITE;
/*!40000 ALTER TABLE `CustomerCred` DISABLE KEYS */;
INSERT INTO `CustomerCred` VALUES ('1318811986','1318811986','notaverysecurepassword'),('1352709817','1352709817','m3dium5tR3gNG7HPassw0rd'),('1381719994','1381719994','h1gH!5tr3nG7H.NOTAHASH'),('1442263916','1442263916','CoKESN'),('1787526756','1787526756','Yv6xMLaGW'),('1925114188','1925114188','bY4YRbj74'),('2028332842','2028332842','iAQIZFEIZ'),('2279675601','2279675601','SObmz2nLnI5T'),('2716649424','2716649424','wpFetHhQGqGc'),('2823619328','2823619328','Psj4V3ahnADc'),('2925663685','2925663685','88haXi'),('3326195615','3326195615','FDB4xu1k5'),('3504895658','3504895658','vfhDfQOcBL0'),('3797368836','3797368836','ybMveZwF5Vbc'),('4026788575','4026788575','lRnQkE'),('4094566755','4094566755','ZDrmlKhCOD'),('4287332730','4287332730','IX5ub9wTXH1i'),('4319002825','4319002825','zqr1aH0Ic'),('4412407880','4412407880','AcGRyWq'),('4431551615','4431551615','eZnNabHHb'),('4513996481','4513996481','9VLv0kvxF'),('4928048948','4928048948','jfQyklGa2Yi'),('5046394625','5046394625','hiTDsIorSdqD'),('5061693330','5061693330','93jpJSVngQvG'),('5067229153','5067229153','vGRtn0f'),('5326189365','5326189365','ajUPzTz4G8y'),('5334619977','5334619977','Kr5uuXB'),('5352183484','5352183484','X4FL2aDC3gS'),('5808875364','5808875364','Mv1wHxNzzdPf'),('5846462104','5846462104','t0Ii8ODBtAb8'),('5951375678','5951375678','ts8JYsutIcjE'),('5969693637','5969693637','LXiYg5pmvV'),('6007695751','6007695751','p5TOeVBR1GfY'),('6395265021','6395265021','NnYnJlFKKy'),('7165050817','7165050817','jxbgzCdJ1'),('7213390650','7213390650','T51BLV'),('7621939193','7621939193','URvbrFBOP9HS'),('7643226405','7643226405','7iZuQMe7DWf2'),('7692294969','7692294969','d6Ycyj30hB'),('8065191195','8065191195','NI7TdEY1'),('8204911992','8204911992','Bl3FlKbV1m'),('8679067318','8679067318','KgU6JU0qKieM'),('8969172424','8969172424','Yv6xMLaGWAn'),('8986139597','8986139597','raEOrQPx6'),('9039125622','9039125622','NtcczMQYOGAe'),('9049887367','9049887367','31EyQ5q7gNt6'),('9358579997','9358579997','Wvr2dqU6Tf1'),('9438651368','9438651368','69YkokwHOpd0'),('9966789408','9966789408','VgFjeiolB');
/*!40000 ALTER TABLE `CustomerCred` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Distributor`
--

DROP TABLE IF EXISTS `Distributor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Distributor` (
  `sellerID` int(11) NOT NULL,
  `phoneNumber` varchar(20) NOT NULL,
  `distName` varchar(20) NOT NULL,
  PRIMARY KEY (`sellerID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Distributor`
--

LOCK TABLES `Distributor` WRITE;
/*!40000 ALTER TABLE `Distributor` DISABLE KEYS */;
INSERT INTO `Distributor` VALUES (10515,'118-757-4872','Centizu'),(11155,'848-517-0970','Aimbo'),(11773,'924-489-9504','Zoozzy'),(13993,'855-595-3637','Wikivu'),(16101,'527-307-4014','Avavee'),(17112,'699-427-5801','Oba'),(17780,'198-121-9796','Trudeo');
/*!40000 ALTER TABLE `Distributor` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Employee`
--

DROP TABLE IF EXISTS `Employee`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Employee` (
  `employeeID` int(11) NOT NULL,
  `jobTypeID` varchar(20) NOT NULL,
  `payRate` float NOT NULL,
  `employeeName` varchar(20) NOT NULL,
  `hireDate` date NOT NULL,
  PRIMARY KEY (`employeeID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Employee`
--

LOCK TABLES `Employee` WRITE;
/*!40000 ALTER TABLE `Employee` DISABLE KEYS */;
INSERT INTO `Employee` VALUES (1,'Cashier',15,'Kania Elven','2021-12-30'),(2,'Cashier',17,'Vanni Willingam','2021-10-30'),(4,'Stocker',15,'Stacee Mossop','2021-06-03'),(5,'Stocker',16,'Noe Morena','2022-01-28'),(6,'Stocker',16,'Isiahi Malser','2021-12-14'),(7,'Unloader',17,'Angie Puddicombe','2021-07-28'),(8,'Unloader',15,'Daniella Waything','2022-01-15'),(9,'Stocker',18,'Moll Kunze','2021-08-28'),(10,'Manager',30,'Wyndham Cullinane','2022-03-21');
/*!40000 ALTER TABLE `Employee` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`etapiaramire`@`localhost`*/ /*!50003 TRIGGER promoteEmployee
AFTER UPDATE ON Employee
FOR EACH ROW
BEGIN
IF NEW.jobTypeID = 'Manager' THEN
INSERT INTO Manager VALUES (NEW.employeeID);
END IF;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`acardenassil`@`localhost`*/ /*!50003 TRIGGER terminateEmployee
BEFORE DELETE ON Employee
FOR EACH ROW
BEGIN
DELETE FROM EmployeeCred WHERE employeeID = OLD.employeeID;
DELETE FROM Manager WHERE managerID = OLD.employeeID;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `EmployeeCred`
--

DROP TABLE IF EXISTS `EmployeeCred`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `EmployeeCred` (
  `employeeID` int(11) NOT NULL,
  `password` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`employeeID`),
  CONSTRAINT `EmployeeCred_ibfk_1` FOREIGN KEY (`employeeID`) REFERENCES `Employee` (`employeeID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `EmployeeCred`
--

LOCK TABLES `EmployeeCred` WRITE;
/*!40000 ALTER TABLE `EmployeeCred` DISABLE KEYS */;
INSERT INTO `EmployeeCred` VALUES (1,'imacashier'),(2,'Imm4Qu17500N'),(4,'yy4iij3nb2b'),(5,'9472uignsvks'),(6,'poiuzxc24nm09876'),(7,'SObmz2nLnI5T'),(8,'ybMveZwF5Vbc'),(9,'URvbrFBOP9HS'),(10,'mysupersecurepasswordasmanager');
/*!40000 ALTER TABLE `EmployeeCred` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Item`
--

DROP TABLE IF EXISTS `Item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Item` (
  `itemNumber` int(11) NOT NULL,
  `itemCount` int(11) NOT NULL,
  `itemPrice` float NOT NULL,
  `storageType` varchar(20) NOT NULL,
  `expirationDate` date NOT NULL,
  `itemLocation` varchar(20) NOT NULL,
  PRIMARY KEY (`itemNumber`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Item`
--

LOCK TABLES `Item` WRITE;
/*!40000 ALTER TABLE `Item` DISABLE KEYS */;
INSERT INTO `Item` VALUES (100436822,82,8.51,'Frozen','2021-11-04','Y0'),(102413192,35,3.32,'Shelf','2022-03-12','X6'),(105893199,91,14.34,'Shelf','2021-11-25','B1'),(111894452,85,5.01,'Shelf','2021-05-29','Z6'),(121532469,41,10.03,'Frozen','2021-12-13','I0'),(121576096,73,3.98,'Fridge','2021-09-23','D1'),(130083855,66,7.31,'Shelf','2021-08-21','Z6'),(136551452,2,2.58,'Frozen','2021-04-08','U0'),(136589416,84,1.71,'Shelf','2021-06-27','Q7'),(138131824,56,1.59,'Shelf','2021-09-20','A3'),(139566914,53,6.05,'Frozen','2021-06-25','F8'),(145156601,57,10.95,'Shelf','2021-10-15','K5'),(149691597,52,4.89,'Shelf','2021-07-21','A3'),(150205078,18,6.32,'Shelf','2022-03-19','H3'),(164994035,66,7.44,'Frozen','2021-04-12','Y2'),(175014061,32,12.22,'Fridge','2021-12-25','K6'),(182553560,82,6.99,'Fridge','2021-12-15','A3'),(183830897,5,13.74,'Shelf','2021-07-25','R8'),(191646882,86,12.85,'Fridge','2021-05-21','Y0'),(192837465,23,9.99,'Fridge','2022-10-25','A2'),(196388491,42,12.38,'Shelf','2022-02-06','S2');
/*!40000 ALTER TABLE `Item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Manager`
--

DROP TABLE IF EXISTS `Manager`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Manager` (
  `managerID` int(11) NOT NULL,
  PRIMARY KEY (`managerID`),
  CONSTRAINT `Manager_ibfk_1` FOREIGN KEY (`managerID`) REFERENCES `Employee` (`employeeID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Manager`
--

LOCK TABLES `Manager` WRITE;
/*!40000 ALTER TABLE `Manager` DISABLE KEYS */;
INSERT INTO `Manager` VALUES (10);
/*!40000 ALTER TABLE `Manager` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SHIPS`
--

DROP TABLE IF EXISTS `SHIPS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `SHIPS` (
  `sellerID` int(11) NOT NULL,
  `itemNumber` int(11) NOT NULL,
  `shipmentID` int(11) NOT NULL,
  `shipDate` date NOT NULL,
  `shipItemCount` int(11) NOT NULL,
  PRIMARY KEY (`sellerID`,`itemNumber`,`shipmentID`),
  KEY `itemNumber` (`itemNumber`),
  CONSTRAINT `SHIPS_ibfk_1` FOREIGN KEY (`sellerID`) REFERENCES `Distributor` (`sellerID`),
  CONSTRAINT `SHIPS_ibfk_2` FOREIGN KEY (`itemNumber`) REFERENCES `Item` (`itemNumber`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SHIPS`
--

LOCK TABLES `SHIPS` WRITE;
/*!40000 ALTER TABLE `SHIPS` DISABLE KEYS */;
INSERT INTO `SHIPS` VALUES (10515,102413192,292534,'2021-10-17',54),(10515,111894452,241691,'2021-12-13',66),(10515,121532469,275685,'2021-05-10',100),(10515,121532469,299345,'2022-05-20',75),(10515,136589416,258755,'2021-11-17',150),(10515,136589416,273351,'2021-11-03',50),(10515,138131824,221069,'2021-04-09',58),(10515,150205078,216156,'2021-06-24',50),(10515,175014061,238416,'2021-07-07',62),(10515,175014061,239097,'2021-10-01',50),(10515,182553560,220120,'2022-01-21',100),(10515,191646882,271248,'2022-01-08',200),(11155,105893199,244290,'2021-09-14',150),(11155,105893199,251449,'2021-11-30',51),(11155,111894452,217071,'2021-10-25',200),(11155,121532469,223555,'2021-07-11',67),(11155,121532469,249383,'2022-01-02',100),(11155,136551452,257441,'2021-12-19',63),(11155,136551452,285469,'2021-11-24',100),(11155,139566914,299116,'2021-10-14',100),(11155,145156601,280218,'2021-12-16',59),(11155,150205078,294539,'2021-10-15',55),(11155,175014061,214319,'2021-12-09',100),(11155,175014061,2143195598,'2021-12-09',100),(11155,182553560,207703,'2021-12-01',100),(11155,182553560,2077039226,'2021-12-01',100),(11155,183830897,276328,'2021-08-15',100),(11155,191646882,264942,'2021-12-27',100),(11773,100436822,247398,'2022-01-27',50),(11773,102413192,289456,'2021-10-18',150),(11773,139566914,218722,'2021-11-15',70),(11773,149691597,222629,'2021-04-10',50),(11773,182553560,200439,'2021-06-21',200),(11773,182553560,2004393867,'2021-06-21',200),(11773,196388491,273712,'2021-11-21',50),(13993,100436822,266981,'2022-01-01',200),(13993,102413192,285059,'2022-01-13',50),(13993,102413192,287467,'2021-05-16',76),(13993,105893199,206040,'2021-12-23',73),(13993,105893199,2060407012,'2021-12-23',73),(13993,111894452,279426,'2021-07-21',100),(13993,121576096,201632,'2021-10-14',75),(13993,121576096,294221,'2021-05-27',53),(13993,121576096,2016321434,'2021-10-14',75),(13993,130083855,229662,'2021-10-18',100),(13993,136551452,299335,'2021-12-31',61),(13993,136589416,249356,'2021-05-26',72),(13993,138131824,274297,'2021-12-27',150),(13993,145156601,224503,'2022-02-15',100),(13993,145156601,255252,'2021-12-15',50),(13993,149691597,246998,'2021-12-08',74),(13993,150205078,224719,'2022-03-01',77),(13993,164994035,245631,'2022-02-28',150),(13993,183830897,290494,'2021-05-16',200),(13993,183830897,299183,'2021-09-15',100),(13993,191646882,238005,'2021-05-19',65),(13993,196388491,203843,'2021-08-13',150),(13993,196388491,285039,'2021-04-05',57),(13993,196388491,2038438395,'2021-08-13',150),(16101,105893199,275841,'2022-01-07',100),(16101,121576096,265642,'2021-07-26',150),(16101,130083855,275592,'2021-08-14',200),(16101,136551452,251438,'2021-12-12',50),(16101,164994035,255513,'2021-10-02',50),(16101,182553560,237600,'2021-12-28',69),(17112,121576096,292481,'2021-12-09',50),(17112,138131824,278257,'2021-08-22',50),(17112,139566914,270257,'2021-04-09',200),(17112,150205078,221372,'2021-08-07',150),(17112,183830897,266513,'2021-09-02',71),(17112,191646882,273037,'2021-05-16',50),(17780,100436822,295858,'2021-10-23',100),(17780,100436822,298680,'2021-07-24',64),(17780,111894452,234009,'2022-01-31',100),(17780,121532469,247001,'2021-12-21',200),(17780,130083855,253364,'2021-08-30',100),(17780,130083855,277049,'2021-11-27',68),(17780,136589416,281308,'2022-03-13',100),(17780,138131824,252433,'2021-05-17',80),(17780,139566914,261096,'2022-01-17',100),(17780,149691597,206271,'2021-09-03',150),(17780,149691597,253102,'2021-11-13',52),(17780,149691597,2062713345,'2021-09-03',150),(17780,164994035,233686,'2021-11-28',78),(17780,164994035,246180,'2022-03-23',56),(17780,175014061,234438,'2021-10-27',60),(17780,183830897,220783,'2021-12-21',100),(17780,196388491,269606,'2021-09-07',79);
/*!40000 ALTER TABLE `SHIPS` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`acardenassil`@`localhost`*/ /*!50003 TRIGGER addItem
BEFORE UPDATE ON SHIPS
FOR EACH ROW
BEGIN
UPDATE Item
SET Item.itemCount = SHIPS.shipItemCount+Item.itemCount
WHERE Item.itemNumber = SHIPS.itemNumber;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `STOCKS`
--

DROP TABLE IF EXISTS `STOCKS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `STOCKS` (
  `stocksID` int(11) NOT NULL,
  `itemNumber` int(11) NOT NULL,
  `employeeID` int(11) NOT NULL,
  PRIMARY KEY (`stocksID`),
  KEY `employeeID` (`employeeID`),
  KEY `itemNumber` (`itemNumber`),
  CONSTRAINT `STOCKS_ibfk_1` FOREIGN KEY (`employeeID`) REFERENCES `Employee` (`employeeID`),
  CONSTRAINT `STOCKS_ibfk_2` FOREIGN KEY (`itemNumber`) REFERENCES `Item` (`itemNumber`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `STOCKS`
--

LOCK TABLES `STOCKS` WRITE;
/*!40000 ALTER TABLE `STOCKS` DISABLE KEYS */;
INSERT INTO `STOCKS` VALUES (1,100436822,6),(2,191646882,6),(3,111894452,6),(4,121532469,6),(5,130083855,6),(6,182553560,9),(7,139566914,9),(8,183830897,9),(9,136589416,6),(10,105893199,9),(11,149691597,6),(12,121576096,6),(13,102413192,4),(14,150205078,5),(15,164994035,9),(16,196388491,4),(17,138131824,4),(18,145156601,5),(19,175014061,9),(20,136551452,9),(21,100436822,4),(22,191646882,4),(23,111894452,5),(24,121532469,9),(25,130083855,6),(26,182553560,5),(27,139566914,6),(28,183830897,4),(29,136589416,6),(30,105893199,4),(31,149691597,5),(32,121576096,5),(33,102413192,9),(34,150205078,4),(35,164994035,6),(36,196388491,6),(37,138131824,4),(38,145156601,5),(39,175014061,6),(40,136551452,4),(41,100436822,9),(42,191646882,5),(43,111894452,5),(44,121532469,5),(45,130083855,6),(46,182553560,5),(47,139566914,6),(48,183830897,9),(49,136589416,9),(50,105893199,6),(51,149691597,4),(52,121576096,9),(53,102413192,4),(54,150205078,6),(55,164994035,5),(56,196388491,6),(57,138131824,5),(58,145156601,5),(59,175014061,6),(60,136551452,5),(61,100436822,9),(62,191646882,4),(63,111894452,5),(64,121532469,4),(65,130083855,5),(66,182553560,5),(67,139566914,5),(68,183830897,6),(69,136589416,5),(70,105893199,5),(71,149691597,6),(72,121576096,5),(73,102413192,9),(74,150205078,4),(75,164994035,6),(76,196388491,9),(77,138131824,5),(78,145156601,4),(79,175014061,6),(80,136551452,6),(81,100436822,5),(82,191646882,5),(83,111894452,9),(84,121532469,9),(85,130083855,4),(86,182553560,4),(87,139566914,5),(88,183830897,6),(89,136589416,6),(90,105893199,4),(91,149691597,9),(92,121576096,4),(93,102413192,6),(94,150205078,6),(95,164994035,5),(96,196388491,6),(97,138131824,9),(98,145156601,4),(99,175014061,5),(100,136551452,9);
/*!40000 ALTER TABLE `STOCKS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `TransactionContains`
--

DROP TABLE IF EXISTS `TransactionContains`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `TransactionContains` (
  `transactionID` int(11) NOT NULL,
  `itemNumber` int(11) NOT NULL,
  `transactionCount` int(11) NOT NULL,
  PRIMARY KEY (`transactionID`,`itemNumber`),
  KEY `itemNumber` (`itemNumber`),
  CONSTRAINT `TransactionContains_ibfk_1` FOREIGN KEY (`itemNumber`) REFERENCES `Item` (`itemNumber`),
  CONSTRAINT `TransactionContains_ibfk_2` FOREIGN KEY (`transactionID`) REFERENCES `TransactionNum` (`transactionID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `TransactionContains`
--

LOCK TABLES `TransactionContains` WRITE;
/*!40000 ALTER TABLE `TransactionContains` DISABLE KEYS */;
INSERT INTO `TransactionContains` VALUES (1,102413192,2),(1,105893199,2),(1,175014061,2),(1,182553560,2),(1,196388491,1),(2,136551452,2),(2,183830897,2),(3,102413192,1),(3,105893199,2),(3,130083855,1),(3,145156601,2),(3,149691597,1),(3,150205078,1),(3,164994035,1),(3,196388491,1),(4,136551452,2),(4,136589416,2),(4,145156601,1),(4,149691597,2),(4,175014061,1),(5,105893199,1),(5,121576096,2),(5,136551452,1),(5,149691597,2),(5,150205078,2),(5,175014061,1),(6,102413192,2),(6,121576096,2),(6,136589416,2),(6,145156601,1),(6,182553560,1),(6,196388491,2),(7,138131824,2),(7,149691597,1),(7,183830897,1),(8,105893199,1),(8,150205078,1),(8,175014061,1),(8,183830897,2),(8,191646882,1),(9,102413192,1),(9,105893199,1),(9,149691597,1),(10,121576096,2),(10,139566914,1),(10,145156601,1),(10,150205078,1),(10,164994035,2),(10,196388491,1),(11,149691597,2),(12,121576096,1),(12,136551452,1),(12,136589416,1),(12,138131824,2),(12,139566914,2),(12,145156601,1),(12,149691597,1),(12,150205078,1),(12,196388491,2),(13,121576096,1),(13,150205078,1),(13,164994035,1),(13,183830897,1),(13,196388491,2),(15,139566914,1),(15,149691597,1),(15,150205078,1),(16,105893199,1),(16,121576096,2),(16,175014061,1),(17,102413192,2),(17,105893199,1),(17,111894452,2),(17,121576096,2),(17,136589416,1),(17,149691597,2),(18,111894452,2),(18,136589416,1),(18,138131824,1),(18,145156601,1),(18,149691597,2),(18,150205078,1),(18,164994035,1),(19,105893199,1),(19,121576096,1),(19,130083855,2),(19,149691597,2),(19,164994035,2),(20,102413192,1),(20,121576096,2),(20,175014061,1),(20,196388491,2),(21,102413192,1),(21,105893199,2),(21,121576096,2),(21,136551452,1),(21,138131824,1),(21,164994035,1),(22,102413192,1),(22,121576096,1),(22,139566914,2),(22,149691597,1),(23,145156601,1),(24,100436822,2),(24,105893199,1),(24,130083855,1),(24,136589416,2),(24,150205078,1),(24,164994035,2),(25,105893199,2),(25,150205078,2),(25,164994035,1),(25,183830897,2),(25,196388491,1),(26,102413192,1),(26,149691597,2),(26,175014061,1),(27,121576096,2),(27,138131824,1),(27,149691597,1),(27,164994035,1),(27,175014061,2),(27,196388491,1),(28,136589416,1),(28,149691597,1),(28,196388491,1),(29,136589416,2),(29,175014061,2),(30,105893199,2),(30,149691597,1),(30,150205078,1),(30,175014061,1),(31,102413192,2),(31,121576096,1),(31,138131824,2),(31,145156601,1),(31,175014061,2),(31,183830897,1),(31,191646882,1),(32,105893199,2),(32,149691597,2),(32,150205078,2),(32,164994035,1),(32,183830897,1),(33,100436822,1),(33,130083855,1),(33,136589416,2),(33,138131824,2),(33,191646882,1),(33,196388491,2),(34,100436822,2),(34,136551452,2),(34,136589416,2),(34,149691597,2),(34,182553560,1),(34,183830897,1),(34,191646882,1),(34,196388491,1),(35,145156601,1),(35,164994035,2),(35,183830897,1),(35,191646882,2),(36,102413192,1),(36,111894452,1),(36,136589416,1),(36,175014061,1),(36,182553560,2),(36,191646882,2),(37,102413192,1),(37,105893199,2),(37,136551452,2),(37,136589416,1),(37,139566914,1),(37,149691597,2),(37,150205078,2),(38,102413192,2),(38,121576096,1),(38,149691597,2),(38,175014061,2),(39,105893199,2),(39,138131824,1),(39,139566914,1),(39,150205078,2),(39,182553560,2),(39,196388491,2),(40,121576096,1),(40,138131824,1),(40,149691597,2),(40,150205078,1),(41,102413192,1),(41,111894452,2),(41,138131824,1),(41,145156601,2),(41,175014061,1),(41,196388491,1),(42,102413192,2),(42,105893199,1),(42,111894452,1),(42,145156601,2),(43,100436822,2),(43,102413192,1),(43,121576096,1),(43,139566914,1),(43,150205078,1),(43,182553560,2),(44,105893199,1),(44,121576096,2),(44,138131824,2),(44,150205078,2),(44,196388491,2),(45,100436822,2),(45,105893199,1),(45,136551452,2),(45,138131824,1),(45,145156601,2),(45,149691597,2),(45,182553560,1),(46,149691597,2),(46,175014061,2),(47,121576096,1),(47,130083855,1),(47,149691597,1),(48,102413192,1),(48,111894452,1),(48,121576096,1),(48,136551452,2),(48,139566914,1),(48,145156601,2),(48,149691597,1),(48,164994035,1),(48,175014061,2),(49,102413192,1),(49,136551452,1),(49,139566914,1),(49,149691597,1),(49,150205078,1),(49,164994035,2),(49,182553560,1),(49,196388491,1),(50,100436822,2),(50,102413192,2),(50,136551452,1),(50,138131824,1),(50,145156601,1),(50,164994035,1),(50,175014061,2),(50,182553560,2);
/*!40000 ALTER TABLE `TransactionContains` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `TransactionNum`
--

DROP TABLE IF EXISTS `TransactionNum`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `TransactionNum` (
  `transactionID` int(11) NOT NULL,
  `employeeID` int(11) NOT NULL,
  `customerPhone` varchar(20) NOT NULL,
  `transactionDate` date NOT NULL,
  `transactionType` varchar(20) NOT NULL,
  `purchaseID` int(11) NOT NULL,
  PRIMARY KEY (`transactionID`,`employeeID`),
  KEY `employeeID` (`employeeID`),
  CONSTRAINT `TransactionNum_ibfk_1` FOREIGN KEY (`employeeID`) REFERENCES `Employee` (`employeeID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `TransactionNum`
--

LOCK TABLES `TransactionNum` WRITE;
/*!40000 ALTER TABLE `TransactionNum` DISABLE KEYS */;
INSERT INTO `TransactionNum` VALUES (1,1,'9049887367','2021-08-02','0',0),(2,1,'9358579997','2021-07-29','0',0),(3,1,'5352183484','2021-11-26','0',0),(4,1,'1381719994','2021-05-30','0',0),(5,1,'2716649424','2021-08-16','0',0),(6,1,'9039125622','2022-01-04','0',0),(7,1,'4319002825','2021-11-28','0',0),(8,1,'2823619328','2021-12-13','0',0),(9,1,'1925114188','2022-02-11','0',0),(10,1,'2028332842','2022-02-15','0',0),(11,1,'5046394625','2021-07-19','0',0),(12,1,'7643226405','2021-08-30','0',0),(13,1,'8679067318','2021-11-27','0',0),(15,1,'1318811986','2021-09-21','0',0),(16,1,'5061693330','2021-11-08','0',0),(17,1,'2925663685','2021-08-03','0',0),(18,1,'7621939193','2021-12-19','0',0),(19,1,'7213390650','2021-07-06','0',0),(20,1,'4928048948','2022-01-08','0',0),(21,1,'4287332730','2021-05-25','0',0),(22,1,'5326189365','2022-01-12','0',0),(23,1,'9966789408','2022-02-04','0',0),(24,1,'5969693637','2021-07-12','0',0),(25,1,'8065191195','2021-09-30','0',0),(26,2,'3326195615','2021-07-17','0',0),(27,2,'1352709817','2021-06-28','0',0),(28,2,'8204911992','2021-04-15','0',0),(29,2,'5334619977','2021-10-03','0',0),(30,2,'4431551615','2021-09-12','0',0),(31,2,'4513996481','2022-03-02','0',0),(32,2,'5846462104','2021-05-17','0',0),(33,2,'3504895658','2021-05-17','0',0),(34,2,'9438651368','2021-09-02','0',0),(35,2,'2279675601','2021-09-01','0',0),(36,2,'3797368836','2021-09-06','0',0),(37,2,'7692294969','2021-09-03','0',0),(38,2,'8986139597','2021-05-02','0',0),(39,2,'5067229153','2021-09-09','0',0),(40,2,'6395265021','2021-08-03','0',0),(41,2,'6007695751','2021-08-19','0',0),(42,2,'5951375678','2022-02-23','0',0),(43,2,'1442263916','2022-02-19','0',0),(44,2,'4412407880','2022-01-05','0',0),(45,2,'8969172424','2021-10-08','0',0),(46,2,'4094566755','2021-10-02','1',1),(47,2,'1787526756','2021-11-24','1',2),(48,2,'7165050817','2021-12-11','1',3),(49,2,'5808875364','2021-05-09','1',4),(50,2,'4026788575','2022-01-20','1',5);
/*!40000 ALTER TABLE `TransactionNum` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `storageInfo`
--

DROP TABLE IF EXISTS `storageInfo`;
/*!50001 DROP VIEW IF EXISTS `storageInfo`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `storageInfo` (
  `employeeID` tinyint NOT NULL,
  `itemNumber` tinyint NOT NULL,
  `itemLocation` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `viewPersonnel`
--

DROP TABLE IF EXISTS `viewPersonnel`;
/*!50001 DROP VIEW IF EXISTS `viewPersonnel`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `viewPersonnel` (
  `employeeID` tinyint NOT NULL,
  `managerID` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Final view structure for view `storageInfo`
--

/*!50001 DROP TABLE IF EXISTS `storageInfo`*/;
/*!50001 DROP VIEW IF EXISTS `storageInfo`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`acardenassil`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `storageInfo` AS select `Employee`.`employeeID` AS `employeeID`,`Item`.`itemNumber` AS `itemNumber`,`Item`.`itemLocation` AS `itemLocation` from ((`Employee` join `STOCKS` on(`Employee`.`employeeID` = `STOCKS`.`employeeID`)) join `Item` on(`Item`.`itemNumber` = `STOCKS`.`itemNumber`)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `viewPersonnel`
--

/*!50001 DROP TABLE IF EXISTS `viewPersonnel`*/;
/*!50001 DROP VIEW IF EXISTS `viewPersonnel`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`acardenassil`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `viewPersonnel` AS select `Employee`.`employeeID` AS `employeeID`,`Manager`.`managerID` AS `managerID` from (`Employee` join `Manager`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-05-20 10:39:32
